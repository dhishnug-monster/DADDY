# DADDY — Your Personal Assistant

DADDY is a browser-based workspace with an Express API and configurable AI provider. For online use, deploy the frontend and backend together. A school/college Windows PC then needs only Chrome or Edge and internet access; the hosted server handles AI credentials and provider requests.

## Current features and data storage

The current UI includes dashboard, AI chat, tasks, study tools, timetable, notes, budget, focus timer, and settings. These modules use browser `localStorage`, including chat history; data remains in the browser profile and does not sync between computers. The Prisma schema defines users, conversations, tasks, notes, reminders, timetable events, transactions, and memories, but the current app does not yet use Prisma-backed routes or account synchronization. Quiz/flashcard, document, achievements, and Confetti Cannon features are not implemented in this checkout. This deployment keeps the existing app as it is and does not imply those absent features are ready.

## Deploy online (Render)

This repository includes `render.yaml`. Connect the repository in Render as a Blueprint and deploy its web service. The production build compiles the React/Vite frontend and TypeScript API; the Express server serves `frontend/dist` and `/api` from the same HTTPS origin. Use an always-on service plan for dependable school access. A free plan is useful for demos, but may sleep when idle; see Render's current limits.

Set the server-side AI environment values:

```text
AI_PROVIDER=openai-compatible
AI_BASE_URL=https://api.groq.com/openai/v1
AI_API_KEY=<provider key stored in Render, not in the frontend>
AI_MODEL=<active provider model>
NODE_ENV=production
TRUST_PROXY=1
```

The first visit opens DADDY's account and AI setup screen. Its setup API stores the Groq key in the backend environment and hashes the account password; the browser receives only an HTTP-only session cookie. Groq is one compatible service; other providers can be configured server-side. Provider usage and free tiers depend on the provider's current terms.

After deploy, open the service URL in Chrome/Edge and check `/api/health` and `/api/ai/status`. The health route checks backend liveness without making a paid AI request. The AI status route returns only provider name, model, configured state, and status; never the key.

See [docs/deployment.md](docs/deployment.md) for the full deployment walkthrough and configuration.

## Local development

Install Node.js 20+ (the `start-daddy.bat` launcher can bootstrap pnpm when Corepack or npm is available). Or install pnpm and run from the repository root:

```powershell
pnpm install
Copy-Item backend/.env.example backend/.env
pnpm --filter @daddy/backend dev
pnpm --filter @daddy/frontend dev
```

Open `http://localhost:5173`; Vite proxies `/api` to `http://localhost:3001`. The first run shows account and Groq setup. The API key is saved only in ignored `backend/.env`; account password hashes and a generated session secret are kept there as well. Later visits show sign-in, and Settings → AI Configuration changes the key/model without revealing the saved key. Model discovery is available from Groq, and manual model IDs are accepted. Ollama remains optional. Never put provider credentials in frontend variables or any `VITE_*` setting.

## Environment variables

| Variable | Purpose |
|---|---|
| `PORT` | HTTP listener; supplied by the host in production, defaults to `3001` locally. |
| `NODE_ENV` | Set to `production` to serve the built frontend from Express. |
| `AI_PROVIDER` | Defaults to `openai-compatible`; set `ollama` to opt into local Ollama. |
| `AI_BASE_URL` | Compatible provider base URL before `/chat/completions`; example uses Groq. |
| `AI_API_KEY` | Provider credential. Backend only; keep it in server secrets. |
| `AI_MODEL` | Provider's active chat model identifier. |
| `OLLAMA_BASE_URL` / `OLLAMA_MODEL` | Optional Ollama settings when `AI_PROVIDER=ollama`. |
| `CORS_ORIGINS` | Comma-separated exact origins if frontend and backend are hosted separately. Same-origin production needs no extra origin. |
| `TRUST_PROXY` | Set to `1` behind a trusted hosting proxy so IP-based rate limits work correctly. |
| `AI_RATE_LIMIT_PER_MINUTE` | Per-client AI request limit; defaults to `10` per minute. |
| `DATABASE_URL` | PostgreSQL URL for Prisma schema tools; current UI/API data is not DB-backed yet. |
| `JWT_SECRET` | Generated and saved by first-run setup for signed server sessions. |
| `DADDY_USERNAME` / `DADDY_PASSWORD_HASH` | Created by first-run setup; the password is stored as a bcrypt hash. |

## API

- `GET /api/health` — API liveness for monitoring.
- `GET /api/setup/status`, `GET /api/auth/status` — setup and session state without credentials.
- `POST /api/setup/models`, `POST /api/setup/test`, `POST /api/setup/save` — backend-side Groq setup.
- `POST /api/auth/login`, `POST /api/auth/logout` — account session lifecycle.
- `PUT /api/ai/config` — authenticated AI configuration update.
- `GET /api/ai/status` — selected AI provider, model, and configuration status without secrets.
- `POST /api/chat` — authenticated conversation; provider calls happen from the backend only.

## Checks and builds

```sh
pnpm test
pnpm run lint
pnpm run typecheck
pnpm run build
```

The Prisma schema is the intended PostgreSQL persistence model. Tasks, notes, chat history, and other workspace data remain browser-local in this version; the DADDY account protects access to AI chat and setup rather than syncing that data across devices.
