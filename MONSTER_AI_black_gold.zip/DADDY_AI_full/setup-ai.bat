@echo off
setlocal
where ollama >nul 2>nul
if errorlevel 1 (
  echo Ollama is not installed or not on PATH.
  echo Install it from https://ollama.com/download/windows, then reopen this window.
  echo PowerShell install command: irm https://ollama.com/install.ps1 ^| iex
  pause
  exit /b 1
)
echo Checking local Ollama service...
curl -fsS http://localhost:11434/api/tags >nul 2>nul
if errorlevel 1 start "Ollama service" /min cmd /c "ollama serve"
set tries=0
:waitollama
curl -fsS http://localhost:11434/api/tags >nul 2>nul
if not errorlevel 1 goto pullmodel
set /a tries+=1
if %tries% GEQ 15 (
  echo Ollama did not become ready. Open Ollama and try again.
  pause
  exit /b 1
)
timeout /t 2 /nobreak >nul
goto waitollama
:pullmodel
ollama list | findstr /i "qwen3.5:4b" >nul
if errorlevel 1 (
  echo Downloading the configured local model qwen3.5:4b...
  ollama pull qwen3.5:4b
  if errorlevel 1 exit /b 1
)
echo Local AI is ready. Verify backend status at http://localhost:3001/api/health
pause
