# DADDY architecture

## Production

```text
School PC (Chrome/Edge)
        │ HTTPS, same-origin
        ▼
Render Node web service
  ├── Express API and static React/Vite build
  ├── provider abstraction (server-side credentials only)
  └── configurable AI provider (remote compatible API or optional Ollama)
```

The deployed browser requires no Node.js, Ollama, model download, or AI key. `NODE_ENV=production` makes Express serve the built `frontend/dist` app. Same-origin API requests avoid production CORS setup; `CORS_ORIGINS` allows exact origins if the frontend is hosted separately.

## Local development

```text
Vite at localhost:5173 ── /api proxy ──> Express at localhost:3001
                                              ├── Ollama (optional)
                                              └── compatible remote AI provider
```

Ollama remains an optional local provider. Choose the AI provider using backend environment variables; provider selection and secrets are never compiled into Vite frontend code.

## API boundaries

- `GET /api/health` reports API liveness and is safe for hosting health checks.
- `GET /api/ai/status` reports the configured provider, model, and readiness without returning secrets or making an AI generation request.
- `POST /api/chat` validates request data, routes deterministic arithmetic locally, then sends other messages through the selected backend provider.
- CORS accepts only configured exact origins. Behind Render, `TRUST_PROXY=1` enables correct client IP handling for rate limits.

## Data and current feature boundaries

The existing UI stores tasks, notes, budget entries, timetable entries, focus sessions, and conversations in browser `localStorage`. They are not synced across computers. Prisma defines PostgreSQL models, but no current application routes use them. Authentication, per-user access, persisted data synchronization, and the listed quiz/flashcard, document, achievements, and Confetti Cannon features are not implemented in this checkout. Do not expose private user data through a shared service until authentication, ownership checks, and database-backed routes are added.
