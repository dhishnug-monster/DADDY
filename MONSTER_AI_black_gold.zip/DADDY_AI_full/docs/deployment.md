# Deploy DADDY online

## Production shape

The Render blueprint deploys one Node web service. It builds the Vite app, and the Express server serves `frontend/dist` and `/api` from the same HTTPS origin. A school computer only needs a modern browser and internet access; it does not install Node, Ollama, a model, or an AI credential.

## Deploy on Render

1. Push this repository to a Git provider and connect it to Render.
2. Choose **New > Blueprint** and select the repository containing `render.yaml`.
3. Keep the `starter` service plan for an always-on deployment, or select a free plan for a demo that may sleep when idle.
4. Set the prompted environment values on the server:
   - `AI_BASE_URL`: provider base URL ending at the version root, such as `https://api.groq.com/openai/v1`.
   - `AI_API_KEY`: a key from the selected provider. Store it in Render's environment settings only.
   - `AI_MODEL`: an active chat model from that provider.
   - `CORS_ORIGINS`: optional comma-separated browser origins if the frontend is hosted separately; same-origin hosting does not need a CORS entry.
5. Deploy and check `https://<your-service>.onrender.com/api/health` and `/api/ai/status`.

The build command creates the static frontend and compiled backend. Render supplies `PORT`; the backend binds to `0.0.0.0`. The configured health check tests backend liveness without consuming an AI request.

## AI provider settings

Set `AI_PROVIDER=openai-compatible`, `AI_BASE_URL`, `AI_API_KEY`, and `AI_MODEL` in the online server's secret/environment settings. DADDY uses the provider's chat-completions HTTP interface directly; no provider SDK is required. This lets you move among compatible providers by changing server configuration and redeploying. The browser never receives `AI_API_KEY`.

For a local-only development environment, keep `AI_PROVIDER=ollama` and optionally set `OLLAMA_BASE_URL` and `OLLAMA_MODEL` in `backend/.env`. Ollama remains an optional backend provider. To use the remote provider in local development, set the same compatible-provider values in `backend/.env`; do not put them in a `VITE_*` variable.

## CORS and health routes

- `CORS_ORIGINS`: comma-separated exact allowed origins for a separately hosted frontend. The app defaults to `http://localhost:5173` in local development.
- `TRUST_PROXY=1`: enable when the service runs behind the Render proxy so request IPs and rate limits use forwarded client addresses.
- `AI_RATE_LIMIT_PER_MINUTE`: per-client chat limit; defaults to 10 requests per minute.
- `GET /api/health`: API liveness only; safe for platform health checks.
- `GET /api/ai/status`: provider name, model, configuration state, and status. It never returns an API key.

## Data persistence limitation

The existing tasks, notes, budget, timetable, study timer, and chat history are saved in browser `localStorage`. They stay on that browser profile/device and do not sync to another computer. Prisma defines PostgreSQL models, but the current application does not yet use database-backed routes, authentication, or account synchronization. A hosted app therefore deploys those current features, but signing in on a different school PC will not retrieve the first PC's local data. Add authenticated database-backed APIs before relying on cross-device persistence or confidential personal data.
