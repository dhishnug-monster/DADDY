import { randomBytes } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

const envPath = process.env.DADDY_ENV_FILE ?? fileURLToPath(new URL('../../.env', import.meta.url));

/** Writes backend-only setup values to the ignored server environment file. */
export async function persistSetup(values: Record<string, string>): Promise<void> {
  let lines: string[] = [];
  try {
    lines = (await readFile(envPath, 'utf8')).split(/\r?\n/);
  } catch {
    // A first run may not have a backend .env yet.
  }
  for (const [key, value] of Object.entries(values)) {
    const line = `${key}=${value.replace(/[\r\n]/g, '')}`;
    const index = lines.findIndex((entry) => entry.startsWith(`${key}=`));
    if (index < 0) lines.push(line);
    else lines[index] = line;
    process.env[key] = value;
  }
  await writeFile(envPath, `${lines.filter((line, index) => line || index < lines.length - 1).join('\n').replace(/\n*$/, '')}\n`, { mode: 0o600 });
}

export function newSessionSecret(): string {
  return randomBytes(48).toString('hex');
}
