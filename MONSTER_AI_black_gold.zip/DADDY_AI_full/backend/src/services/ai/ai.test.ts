import { afterEach, describe, expect, it, vi } from 'vitest';
import { OllamaProvider } from './ollamaProvider.js';
import { solveMath } from './mathService.js';
import { detectIntent } from './intentService.js';
import { CompatibleProvider } from './compatibleProvider.js';
import { createAIProvider } from './providerFactory.js';

afterEach(() => vi.unstubAllGlobals());

describe('local AI services', () => {
  it('recognizes Ollama online and missing-model states', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(Response.json({ models: [{ name: 'other:latest' }] })));
    expect((await new OllamaProvider('http://localhost:11434', 'qwen3.5:4b').health()).connectionStatus).toBe('model_missing');
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new Error('offline')));
    expect((await new OllamaProvider().health()).connectionStatus).toBe('offline');
  });
  it('parses deterministic arithmetic and percentages safely', () => {
    expect(solveMath('Calculate 2^3 + 4')).toBe('12');
    expect(solveMath('What is 15% of 80?')).toBe('12');
    expect(solveMath('1 / 0')).toBeUndefined();
    expect(solveMath('process.exit()')).toBeUndefined();
  });
  it('categorizes common requests', () => {
    expect(detectIntent('Make me a 5 mark answer about photosynthesis')).toBe('exam');
    expect(detectIntent('Set a reminder for tomorrow')).toBe('reminder');
    expect(detectIntent('Hello DADDY')).toBe('general');
  });
  it('sends compatible provider requests with credentials only in server headers', async () => {
    const fetchMock = vi.fn().mockResolvedValue(Response.json({ choices: [{ message: { content: 'Remote reply' } }] }));
    vi.stubGlobal('fetch', fetchMock);
    const provider = new CompatibleProvider('https://api.example.test/v1', 'demo-model', 'fake-test-key');
    expect((await provider.health()).connectionStatus).toBe('configured');
    await expect(provider.chat([{ role: 'user', content: 'Hello' }])).resolves.toBe('Remote reply');
    expect(fetchMock).toHaveBeenCalledWith('https://api.example.test/v1/chat/completions', expect.objectContaining({
      headers: expect.objectContaining({ authorization: 'Bearer fake-test-key' }),
    }));
  });
  it('selects the compatible provider from server environment configuration', () => {
    const provider = createAIProvider({ AI_PROVIDER: 'openai-compatible', AI_BASE_URL: 'https://api.example.test/v1', AI_MODEL: 'test', AI_API_KEY: 'fake-test-key' });
    expect(provider.constructor.name).toBe('CompatibleProvider');
  });
});
