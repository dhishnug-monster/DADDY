/** Evaluate a deliberately small arithmetic grammar; never uses eval or Function. */
export function solveMath(input: string): string | undefined {
  const text = input.trim().replace(/,/g, '');
  const percent = text.match(/^(?:what is\s+)?(-?\d+(?:\.\d+)?)\s*%\s+of\s+(-?\d+(?:\.\d+)?)\??$/i);
  if (percent) return format((Number(percent[1]) / 100) * Number(percent[2]));
  const root = text.match(/^(?:sqrt|square root of)\s*\(?\s*(\d+(?:\.\d+)?)\s*\)?\??$/i);
  if (root) return format(Math.sqrt(Number(root[1])));
  const expression = text.replace(/^(?:calculate|compute|solve|what is)\s+/i, '').replace(/\?$/, '').trim();
  if (!expression || !/^[\d\s.+*/^()%-]+$/.test(expression)) return undefined;
  try {
    const parser = new Parser(expression);
    const value = parser.expression();
    if (!parser.done() || !Number.isFinite(value)) return undefined;
    return format(value);
  } catch {
    return undefined;
  }
}

function format(value: number) {
  if (!Number.isFinite(value)) return 'That calculation is undefined.';
  return Number(value.toPrecision(12)).toString();
}

class Parser {
  private index = 0;
  constructor(private readonly text: string) {}
  done() { this.space(); return this.index === this.text.length; }
  expression(): number {
    let value = this.term();
    while (true) {
      this.space();
      if (this.take('+')) value += this.term();
      else if (this.take('-')) value -= this.term();
      else return value;
    }
  }
  private term(): number {
    let value = this.power();
    while (true) {
      this.space();
      if (this.take('*')) value *= this.power();
      else if (this.take('/')) { const divisor = this.power(); if (divisor === 0) throw new Error(); value /= divisor; }
      else if (this.take('%')) value %= this.power();
      else return value;
    }
  }
  private power(): number {
    let value = this.unary();
    this.space();
    if (this.take('^')) value **= this.power();
    return value;
  }
  private unary(): number {
    this.space();
    if (this.take('+')) return this.unary();
    if (this.take('-')) return -this.unary();
    if (this.take('(')) { const result = this.expression(); this.space(); if (!this.take(')')) throw new Error(); return result; }
    const match = this.text.slice(this.index).match(/^\d+(?:\.\d+)?/);
    if (!match) throw new Error();
    this.index += match[0].length;
    return Number(match[0]);
  }
  private take(char: string) { if (this.text[this.index] !== char) return false; this.index++; return true; }
  private space() { while (/\s/.test(this.text[this.index] ?? '\0')) this.index++; }
}
