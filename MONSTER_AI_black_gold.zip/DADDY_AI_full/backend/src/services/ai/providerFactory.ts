import { AIProviderError, type AIProvider } from './aiProvider.js';
import { FallbackProvider } from './fallbackProvider.js';
import { CompatibleProvider } from './compatibleProvider.js';
import { OllamaProvider } from './ollamaProvider.js';

export function createAIProvider(config = process.env): AIProvider {
  const provider = (config.AI_PROVIDER ?? 'openai-compatible').trim().toLowerCase();
  if (provider === 'ollama') {
    return new FallbackProvider(
      new OllamaProvider(
        config.OLLAMA_BASE_URL ?? 'http://localhost:11434',
        config.OLLAMA_MODEL ?? 'qwen3.5:4b',
      ),
    );
  }
  if (provider === 'openai-compatible' || provider === 'compatible') {
    return new CompatibleProvider(config.AI_BASE_URL, config.AI_MODEL, config.AI_API_KEY);
  }
  return new FallbackProvider(new UnavailableProvider(provider, config.OLLAMA_MODEL ?? 'qwen3.5:4b'));
}

class UnavailableProvider implements AIProvider {
  constructor(private readonly provider: string, private readonly model: string) {}
  async health() {
    return { provider: this.provider, model: this.model, available: false, connectionStatus: 'unsupported' as const };
  }
  async chat(): Promise<string> {
    throw new AIProviderError(`Unsupported AI provider: ${this.provider}.`, 'provider_error');
  }
}
