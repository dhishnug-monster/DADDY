import type { AIHealth, AIProvider, ChatMessage } from './aiProvider.js';
import { AIProviderError } from './aiProvider.js';

type CompletionResponse = {
  choices?: Array<{ message?: { content?: string | Array<{ type?: string; text?: string }> } }>;
};

/** Works with providers exposing the OpenAI chat-completions HTTP contract. */
export class CompatibleProvider implements AIProvider {
  readonly name = 'openai-compatible';

  constructor(
    private readonly baseUrl = process.env.AI_BASE_URL ?? 'https://api.groq.com/openai/v1',
    readonly model = process.env.AI_MODEL ?? 'openai/gpt-oss-20b',
    private readonly apiKey = process.env.AI_API_KEY ?? '',
  ) {}

  async health(): Promise<AIHealth> {
    const configured = Boolean(this.baseUrl && this.model && this.apiKey);
    return {
      provider: this.name,
      available: configured,
      model: this.model || 'not configured',
      connectionStatus: configured ? 'configured' : 'unconfigured',
    };
  }

  async chat(messages: ChatMessage[]): Promise<string> {
    const health = await this.health();
    if (!health.available) {
      throw new AIProviderError('Remote AI provider configuration is incomplete.', 'not_configured');
    }

    let response: Response;
    try {
      response = await fetch(`${this.baseUrl.replace(/\/$/, '')}/chat/completions`, {
        method: 'POST',
        headers: {
          authorization: `Bearer ${this.apiKey}`,
          'content-type': 'application/json',
        },
        body: JSON.stringify({ model: this.model, messages, stream: false }),
        signal: AbortSignal.timeout(90_000),
      });
    } catch {
      throw new AIProviderError('The configured AI service could not be reached.', 'offline');
    }

    if (response.status === 401 || response.status === 403) {
      throw new AIProviderError('The configured AI service rejected its server credentials.', 'provider_error');
    }
    if (response.status === 429) {
      throw new AIProviderError('The configured AI service rate limit was reached.', 'rate_limited');
    }
    if (!response.ok) {
      throw new AIProviderError(`The configured AI service returned HTTP ${response.status}.`, 'provider_error');
    }

    let result: CompletionResponse;
    try {
      result = (await response.json()) as CompletionResponse;
    } catch {
      throw new AIProviderError('The configured AI service returned an invalid response.', 'provider_error');
    }
    const content = result.choices?.[0]?.message?.content;
    const answer = typeof content === 'string'
      ? content.trim()
      : content?.filter((part) => part.type === 'text').map((part) => part.text ?? '').join('').trim();
    if (!answer) throw new AIProviderError('The configured AI service returned an empty response.', 'provider_error');
    return answer;
  }
}
