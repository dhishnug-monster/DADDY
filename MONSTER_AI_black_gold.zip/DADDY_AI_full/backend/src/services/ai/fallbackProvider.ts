import type { AIHealth, AIProvider, ChatMessage } from './aiProvider.js';
import { AIProviderError } from './aiProvider.js';

export class FallbackProvider implements AIProvider {
  constructor(private readonly primary: AIProvider) {}

  async health(): Promise<AIHealth> {
    return this.primary.health();
  }

  async chat(messages: ChatMessage[]): Promise<string> {
    try {
      return await this.primary.chat(messages);
    } catch (error) {
      const health = await this.primary.health();
      if (health.connectionStatus === 'unsupported') {
        return `The configured AI provider "${health.provider}" is not supported. Set AI_PROVIDER=openai-compatible, or explicitly choose the optional ollama provider.`;
      }
      if (error instanceof AIProviderError && error.kind === 'model_missing') {
        return `${error.message} Run "ollama pull ${health.model}" and try again.`;
      }
      return 'Monster AI local AI is not running. Start Ollama and make sure a local model is installed.';
    }
  }

}
