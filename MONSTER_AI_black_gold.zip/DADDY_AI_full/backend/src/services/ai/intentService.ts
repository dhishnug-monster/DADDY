export type Intent =
  | 'math'
  | 'study'
  | 'exam'
  | 'task'
  | 'reminder'
  | 'timetable'
  | 'budget'
  | 'note'
  | 'quiz'
  | 'flashcard'
  | 'document'
  | 'general';

const rules: Array<[Intent, RegExp]> = [
  ['math', /\b(calculate|compute|solve|what is|percent|percentage|sqrt|square root)\b|[\d)]\s*[+*/^%-]\s*[\d(]/i],
  ['exam', /\b(exam|marks?|long answer|short answer|2[- ]mark|5[- ]mark|10[- ]mark)\b/i],
  ['study', /\b(study|explain|teach|learn|summari[sz]e|revision)\b/i],
  ['task', /\b(task|todo|to-do)\b/i],
  ['reminder', /\b(remind|reminder|alert)\b/i],
  ['timetable', /\b(timetable|schedule|calendar|study plan)\b/i],
  ['budget', /\b(budget|expense|income|spend|spent)\b/i],
  ['note', /\b(note|notes|write down)\b/i],
  ['quiz', /\b(quiz|test me)\b/i],
  ['flashcard', /\b(flashcard|flash card)\b/i],
  ['document', /\b(document|essay|report|letter|resume|cv)\b/i],
];

export function detectIntent(message: string): Intent {
  return rules.find(([, pattern]) => pattern.test(message))?.[0] ?? 'general';
}
