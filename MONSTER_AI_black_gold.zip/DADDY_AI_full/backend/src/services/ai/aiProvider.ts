export type ChatMessage = {
  role: 'system' | 'user' | 'assistant';
  content: string;
};

export type AIConnectionStatus = 'online' | 'offline' | 'model_missing' | 'configured' | 'unconfigured' | 'unsupported';

export type AIHealth = {
  provider: string;
  available: boolean;
  model: string;
  connectionStatus: AIConnectionStatus;
};

export interface AIProvider {
  chat(messages: ChatMessage[]): Promise<string>;
  health(): Promise<AIHealth>;
}

export class AIProviderError extends Error {
  constructor(
    message: string,
    readonly kind: 'offline' | 'model_missing' | 'provider_error' | 'not_configured' | 'rate_limited',
  ) {
    super(message);
    this.name = 'AIProviderError';
  }
}
