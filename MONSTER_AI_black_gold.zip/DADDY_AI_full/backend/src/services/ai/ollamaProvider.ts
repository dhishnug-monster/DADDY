import type { AIHealth, AIProvider, ChatMessage } from './aiProvider.js';
import { AIProviderError } from './aiProvider.js';

type OllamaTags = { models?: Array<{ name?: string }> };
type OllamaChatResponse = { message?: { content?: string } };

export class OllamaProvider implements AIProvider {
  readonly name = 'ollama';

  constructor(
    private readonly baseUrl = process.env.OLLAMA_BASE_URL ?? 'http://localhost:11434',
    readonly model = process.env.OLLAMA_MODEL ?? 'qwen3.5:4b',
  ) {}

  private url(path: string) {
    return `${this.baseUrl.replace(/\/$/, '')}${path}`;
  }

  async health(): Promise<AIHealth> {
    try {
      const response = await fetch(this.url('/api/tags'), { signal: AbortSignal.timeout(2500) });
      if (!response.ok) {
        return { provider: this.name, available: false, model: this.model, connectionStatus: 'offline' };
      }
      const data = (await response.json()) as OllamaTags;
      const models = data.models?.map((entry) => entry.name ?? '') ?? [];
      const hasModel = models.some((name) => normalizeModel(name) === normalizeModel(this.model));
      return {
        provider: this.name,
        available: hasModel,
        model: this.model,
        connectionStatus: hasModel ? 'online' : 'model_missing',
      };
    } catch {
      return { provider: this.name, available: false, model: this.model, connectionStatus: 'offline' };
    }
  }

  async chat(messages: ChatMessage[]): Promise<string> {
    let response: Response;
    try {
      response = await fetch(this.url('/api/chat'), {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ model: this.model, messages, stream: false }),
        signal: AbortSignal.timeout(120_000),
      });
    } catch {
      throw new AIProviderError('Ollama is not reachable.', 'offline');
    }

    if (response.status === 404) {
      throw new AIProviderError(`The local model ${this.model} is not installed.`, 'model_missing');
    }
    if (!response.ok) {
      throw new AIProviderError(`Ollama returned HTTP ${response.status}.`, 'provider_error');
    }

    let result: OllamaChatResponse;
    try {
      result = (await response.json()) as OllamaChatResponse;
    } catch {
      throw new AIProviderError('Ollama returned an invalid response.', 'provider_error');
    }
    const answer = result.message?.content?.trim();
    if (!answer) throw new AIProviderError('Ollama returned an empty response.', 'provider_error');
    return answer;
  }
}

function normalizeModel(name: string) {
  return name.trim().replace(/:latest$/, '');
}
