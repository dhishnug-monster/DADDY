import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import { fileURLToPath } from 'node:url';
import { assistantPrompt } from './prompts.js';
import { createAIProvider } from './services/ai/providerFactory.js';
import { detectIntent } from './services/ai/intentService.js';
import { solveMath } from './services/ai/mathService.js';
import { AIProviderError } from './services/ai/aiProvider.js';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { persistSetup, newSessionSecret } from './services/setupConfig.js';

export const app = express();
let aiProvider = createAIProvider();
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      baseUri: ["'self'"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'],
      formAction: ["'self'"],
      frameAncestors: ["'none'"],
      imgSrc: ["'self'", 'data:', 'blob:'],
      objectSrc: ["'none'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
    },
  },
}));
const allowedOrigins = new Set(
  (process.env.CORS_ORIGINS ?? process.env.WEB_ORIGIN ?? 'http://localhost:5173')
    .split(',')
    .map((origin) => origin.trim())
    .filter(Boolean),
);
app.use(cors({ origin: (origin, callback) => callback(null, !origin || allowedOrigins.has(origin)) }));
app.use(express.json({ limit: '1mb' }));
// Render runs behind a single reverse proxy. Trust that proxy so Express
// can safely use X-Forwarded-For for rate limiting and client IP detection.
app.set('trust proxy', 1);
app.use('/api', rateLimit({ windowMs: 60_000, limit: 40, standardHeaders: 'draft-7', legacyHeaders: false }));
const chatRateLimit = rateLimit({
  windowMs: 60_000,
  limit: Number(process.env.AI_RATE_LIMIT_PER_MINUTE ?? 10),
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'Too many AI requests. Please wait a moment and try again.' },
});
app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));
const sessionCookie = 'daddy_session';
function sessionUser(req: express.Request): string | null {
  const cookie = req.headers.cookie?.split(';').map((part) => part.trim()).find((part) => part.startsWith(`${sessionCookie}=`));
  const token = cookie?.slice(sessionCookie.length + 1);
  const secret = process.env.JWT_SECRET;
  if (!token || !secret) return null;
  try {
    const payload = jwt.verify(decodeURIComponent(token), secret);
    return typeof payload === 'object' && typeof payload.sub === 'string' ? payload.sub : null;
  } catch {
    return null;
  }
}
const authenticated = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (!sessionUser(req)) return res.status(401).json({ error: 'Please sign in to continue.' });
  next();
};
const ConfigInput = z.object({
  username: z.string().trim().min(1).max(50),
  password: z.string().min(8).max(200),
  apiKey: z.string().trim().min(1).max(500).optional(),
  model: z.string().trim().min(1).max(200).optional(),
});
const ProviderInput = z.object({ apiKey: z.string().trim().min(1).max(500).optional(), model: z.string().trim().min(1).max(200) });
app.get('/api/setup/status', async (_req, res) => {
  const health = await aiProvider.health();
  res.json({ configured: health.available, hasAccount: Boolean(process.env.DADDY_USERNAME && process.env.DADDY_PASSWORD_HASH), authenticated: Boolean(sessionUser(_req)) });
});
app.get('/api/auth/status', (req, res) => res.json({ authenticated: Boolean(sessionUser(req)), username: sessionUser(req) }));
app.post('/api/auth/login', async (req, res) => {
  const input = z.object({ username: z.string().trim().min(1).max(50), password: z.string().min(1).max(200) }).safeParse(req.body);
  if (!input.success || input.data.username !== process.env.DADDY_USERNAME || !process.env.DADDY_PASSWORD_HASH || !process.env.JWT_SECRET || !(await bcrypt.compare(input.data.password, process.env.DADDY_PASSWORD_HASH))) {
    return res.status(401).json({ error: 'Username or password is incorrect.' });
  }
  const token = jwt.sign({}, process.env.JWT_SECRET, { subject: input.data.username, expiresIn: '7d' });
  res.cookie(sessionCookie, token, { httpOnly: true, sameSite: 'strict', secure: process.env.NODE_ENV === 'production', maxAge: 7 * 24 * 60 * 60 * 1000, path: '/' });
  return res.json({ ok: true, username: input.data.username });
});
app.post('/api/auth/logout', (_req, res) => {
  res.clearCookie(sessionCookie, { httpOnly: true, sameSite: 'strict', secure: process.env.NODE_ENV === 'production', path: '/' });
  res.json({ ok: true });
});
app.post('/api/setup/models', async (req, res) => {
  const input = z.object({ apiKey: z.string().trim().min(1).max(500) }).safeParse(req.body);
  if (!input.success) return res.status(400).json({ error: 'Enter a Groq API key to load models.' });
  try {
    const response = await fetch('https://api.groq.com/openai/v1/models', { headers: { authorization: `Bearer ${input.data.apiKey}` }, signal: AbortSignal.timeout(15000) });
    if (!response.ok) return res.status(response.status === 401 ? 401 : 502).json({ error: response.status === 401 ? 'Groq rejected this API key.' : 'Could not load Groq models.' });
    const data = await response.json() as { data?: Array<{ id?: string }> };
    return res.json({ models: (data.data ?? []).map((model) => model.id).filter((id): id is string => Boolean(id)).sort() });
  } catch {
    return res.status(502).json({ error: 'Could not reach Groq to load models.' });
  }
});
app.post('/api/setup/test', async (req, res) => {
  const input = ProviderInput.safeParse(req.body);
  const key = input.success ? input.data.apiKey ?? process.env.AI_API_KEY : undefined;
  if (!input.success || !key) return res.status(400).json({ error: 'Enter an API key and model, or configure a key on the server first.' });
  try {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', { method: 'POST', headers: { authorization: `Bearer ${key}`, 'content-type': 'application/json' }, body: JSON.stringify({ model: input.data.model, messages: [{ role: 'user', content: 'Reply with: DADDY connection successful.' }], max_tokens: 30 }), signal: AbortSignal.timeout(20000) });
    if (!response.ok) return res.status(response.status === 401 ? 401 : 502).json({ error: response.status === 401 ? 'Groq rejected this API key.' : `Groq returned HTTP ${response.status}. Check that the model is available to your account.` });
    return res.json({ ok: true });
  } catch {
    return res.status(502).json({ error: 'Could not reach Groq. Check your internet connection.' });
  }
});
app.post('/api/setup/save', async (req, res) => {
  const input = ConfigInput.safeParse(req.body);
  if (!input.success) return res.status(400).json({ error: 'Enter a username and password of at least 8 characters.' });
  const hasAccount = Boolean(process.env.DADDY_USERNAME && process.env.DADDY_PASSWORD_HASH);
  if (hasAccount && !sessionUser(req) && (input.data.username !== process.env.DADDY_USERNAME || !(await bcrypt.compare(input.data.password, process.env.DADDY_PASSWORD_HASH!)))) return res.status(401).json({ error: 'Username or password is incorrect.' });
  const apiKey = input.data.apiKey ?? process.env.AI_API_KEY;
  const model = input.data.model ?? process.env.AI_MODEL;
  if (!apiKey || !model) return res.status(400).json({ error: 'Enter your Groq API key and model.' });
  const passwordHash = hasAccount ? process.env.DADDY_PASSWORD_HASH! : await bcrypt.hash(input.data.password, 12);
  const secret = process.env.JWT_SECRET || newSessionSecret();
  await persistSetup({ AI_PROVIDER: process.env.AI_PROVIDER || 'openai-compatible', AI_BASE_URL: process.env.AI_BASE_URL || 'https://api.groq.com/openai/v1', AI_API_KEY: apiKey, AI_MODEL: model, DADDY_USERNAME: hasAccount ? process.env.DADDY_USERNAME! : input.data.username, DADDY_PASSWORD_HASH: passwordHash, JWT_SECRET: secret });
  aiProvider = createAIProvider();
  const token = jwt.sign({}, secret, { subject: hasAccount ? process.env.DADDY_USERNAME! : input.data.username, expiresIn: '7d' });
  res.cookie(sessionCookie, token, { httpOnly: true, sameSite: 'strict', secure: process.env.NODE_ENV === 'production', maxAge: 7 * 24 * 60 * 60 * 1000, path: '/' });
  return res.json({ ok: true });
});
app.put('/api/ai/config', authenticated, async (req, res) => {
  const input = ProviderInput.safeParse(req.body);
  if (!input.success) return res.status(400).json({ error: 'Enter an API key and model.' });
  await persistSetup({ AI_PROVIDER: 'openai-compatible', AI_BASE_URL: 'https://api.groq.com/openai/v1', ...(input.data.apiKey ? { AI_API_KEY: input.data.apiKey } : {}), AI_MODEL: input.data.model });
  aiProvider = createAIProvider();
  return res.json({ ok: true });
});
app.get('/api/ai/status', async (_req, res) => {
  const health = await aiProvider.health();
  res.json({ provider: health.provider, configured: health.available, model: health.model, status: health.connectionStatus });
});
const ChatInput = z.object({
  messages: z.array(z.object({ role: z.enum(['user', 'assistant']), content: z.string().min(1).max(12000) })).min(1).max(40),
});
app.post('/api/chat', authenticated, chatRateLimit, async (req, res) => {
  const parsed = ChatInput.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Please send a valid message.' });
  try {
    const latest = [...parsed.data.messages].reverse().find((message) => message.role === 'user')?.content ?? '';
    if (detectIntent(latest) === 'math') {
      const answer = solveMath(latest);
      if (answer !== undefined) return res.json({ message: answer, intent: 'math', source: 'local' });
    }
    const message = await aiProvider.chat([
      { role: 'system', content: assistantPrompt },
      ...parsed.data.messages,
    ]);
    return res.json({ message, intent: detectIntent(latest) });
  } catch (error) {
    const kind = error instanceof AIProviderError ? error.kind : 'provider_error';
    console.error('AI request failed:', kind);
    const status = kind === 'not_configured' ? 503 : kind === 'rate_limited' ? 429 : 502;
    return res.status(status).json({ error: kind === 'not_configured'
      ? 'The server AI provider is not configured yet.'
      : kind === 'rate_limited'
        ? 'The AI provider is busy. Please wait a moment and try again.'
        : 'Monster AI could not complete that request. Please try again later.' });
  }
});
app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found' }));
if (process.env.NODE_ENV === 'production') {
  const frontendDist = fileURLToPath(new URL('../../frontend/dist/', import.meta.url));
  app.use(express.static(frontendDist, { index: false, maxAge: '1h' }));
  app.get('*', (_req, res) => res.sendFile(fileURLToPath(new URL('../../frontend/dist/index.html', import.meta.url))));
}
app.use((_req, res) => res.status(404).json({ error: 'Not found' }));
app.use((error: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('Unhandled request error:', error instanceof Error ? error.name : 'unknown');
  res.status(500).json({ error: 'Something went wrong. Please try again.' });
});
