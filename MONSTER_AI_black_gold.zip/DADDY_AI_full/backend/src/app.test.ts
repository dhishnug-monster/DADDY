import { afterAll, afterEach, describe, expect, it, vi } from 'vitest';
import request from 'supertest';
import jwt from 'jsonwebtoken';
vi.stubEnv('AI_PROVIDER', 'openai-compatible');
vi.stubEnv('AI_BASE_URL', 'https://provider.example.test/v1');
vi.stubEnv('AI_MODEL', 'test-model');
vi.stubEnv('AI_API_KEY', 'fake-test-key');
vi.stubEnv('JWT_SECRET', 'daddy-unit-test-session-secret');
const { app } = await import('./app.js');
const sessionCookie = `daddy_session=${jwt.sign({}, 'daddy-unit-test-session-secret', { subject: 'tester' })}`;

afterEach(() => vi.unstubAllGlobals());
afterAll(() => vi.unstubAllEnvs());

describe('DADDY API health and chat', () => {
  it('reports API liveness without checking or exposing AI configuration', async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal('fetch', fetchMock);
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ status: 'ok' });
    expect(fetchMock).not.toHaveBeenCalled();
  });
  it('reports provider status without exposing credentials', async () => {
    const res = await request(app).get('/api/ai/status');
    expect(res.status).toBe(200);
    expect(res.body).toMatchObject({ provider: 'openai-compatible', configured: true, model: 'test-model', status: 'configured' });
    expect(Object.keys(res.body)).not.toContain('apiKey');
  });
  it('rejects malformed messages', async () => {
    expect((await request(app).post('/api/chat').set('Cookie', sessionCookie).send({ messages: [] })).status).toBe(400);
  });
  it('requires a signed-in session for chat', async () => {
    expect((await request(app).post('/api/chat').send({ messages: [{ role: 'user', content: 'Hello' }] })).status).toBe(401);
  });
  it('retrieves model choices and tests Groq credentials on the server', async () => {
    const fetchMock = vi.fn()
      .mockResolvedValueOnce(Response.json({ data: [{ id: 'model-a' }, { id: 'model-b' }] }))
      .mockResolvedValueOnce(Response.json({ choices: [{ message: { content: 'ok' } }] }));
    vi.stubGlobal('fetch', fetchMock);
    const models = await request(app).post('/api/setup/models').send({ apiKey: 'fake-test-key' });
    expect(models.body.models).toEqual(['model-a', 'model-b']);
    const tested = await request(app).post('/api/setup/test').send({ apiKey: 'fake-test-key', model: 'model-a' });
    expect(tested.body).toEqual({ ok: true });
    expect(fetchMock.mock.calls[0][1]?.headers).toMatchObject({ authorization: 'Bearer fake-test-key' });
  });
  it('solves arithmetic locally without making a provider call', async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal('fetch', fetchMock);
    const res = await request(app).post('/api/chat').set('Cookie', sessionCookie).send({ messages: [{ role: 'user', content: 'What is 12 * (3 + 2)?' }] });
    expect(res.status).toBe(200);
    expect(res.body).toMatchObject({ message: '60', intent: 'math', source: 'local' });
    expect(fetchMock).not.toHaveBeenCalled();
  });
  it('returns model output from the configured online provider', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(Response.json({ choices: [{ message: { content: 'Hello! How can I help?' } }] })));
    const res = await request(app).post('/api/chat').set('Cookie', sessionCookie).send({ messages: [{ role: 'user', content: 'Hello DADDY' }] });
    expect(res.status).toBe(200);
    expect(res.body.message).toBe('Hello! How can I help?');
  });
  it('returns a sanitized upstream error without leaking internals', async () => {
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new Error('connection refused')));
    const res = await request(app).post('/api/chat').set('Cookie', sessionCookie).send({ messages: [{ role: 'user', content: 'Hello DADDY' }] });
    expect(res.status).toBe(502);
    expect(res.body.error).toMatch(/try again later/i);
    expect(res.body.error).not.toMatch(/connection refused|fake-test-key/i);
  });
});
