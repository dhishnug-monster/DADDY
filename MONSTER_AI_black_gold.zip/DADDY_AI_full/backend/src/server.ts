import dotenv from 'dotenv';
import { fileURLToPath } from 'node:url';
dotenv.config({
  path: process.env.DADDY_ENV_FILE ?? fileURLToPath(new URL('../.env', import.meta.url)),
});
const { app } = await import('./app.js');
const port = Number(process.env.PORT ?? 3001);
app.listen(port, '0.0.0.0', () => console.log(`DADDY server listening on port ${port}`));
