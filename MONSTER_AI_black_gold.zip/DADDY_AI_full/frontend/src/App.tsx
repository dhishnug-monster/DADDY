import { useEffect, useState } from 'react';
import { NavLink, Route, Routes, useNavigate } from 'react-router-dom';
import {
  Activity,
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  CalendarDays,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  FileText,
  Eye,
  EyeOff,
  Flame,
  LayoutDashboard,
  ListTodo,
  Menu,
  MessageSquare,
  Plus,
  Search,
  Send,
  Settings,
  ShieldCheck,
  Sparkles,
  Timer,
  Wallet,
  X,
} from 'lucide-react';

type Task = { id: string; title: string; done: boolean; priority: string; due: string };
type Note = { id: string; title: string; body: string; updated: string };
type Entry = {
  id: string;
  title: string;
  amount: number;
  kind: 'income' | 'expense';
  category: string;
  date: string;
};
type AIHealthView = { provider: string; configured: boolean; model: string; status: string };
const read = <T,>(key: string, fallback: T): T => {
  try {
    return JSON.parse(localStorage.getItem('daddy:' + key) || '') as T;
  } catch {
    return fallback;
  }
};
const save = (key: string, value: unknown) =>
  localStorage.setItem('daddy:' + key, JSON.stringify(value));
const now = new Date();
const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
const seedTasks: Task[] = [
  { id: 'a', title: 'Review database normalization', done: false, priority: 'High', due: today },
  {
    id: 'b',
    title: 'Finish discrete mathematics problem set',
    done: false,
    priority: 'Medium',
    due: today,
  },
  { id: 'c', title: 'Read 20 pages of operating systems', done: true, priority: 'Low', due: today },
];
const seedNotes: Note[] = [
  {
    id: 'n1',
    title: 'DBMS — Normalization',
    body: '1NF: atomic values. 2NF: no partial dependency. 3NF: no transitive dependency.',
    updated: 'Today',
  },
  {
    id: 'n2',
    title: 'Ideas for the week',
    body: 'Focus on one topic at a time. Keep sessions short and review regularly.',
    updated: 'Yesterday',
  },
];
const nav = [
  ['Overview', '/', LayoutDashboard],
  ['AI assistant', '/chat', MessageSquare],
  ['My tasks', '/tasks', ListTodo],
  ['Study planner', '/study', BookOpen],
  ['Timetable', '/timetable', CalendarDays],
  ['Notes', '/notes', FileText],
  ['Budget', '/budget', Wallet],
  ['Settings', '/settings', Settings],
] as const;
function SetupScreen({ configured, hasAccount, onComplete }: { configured: boolean; hasAccount: boolean; onComplete: (username: string) => void }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [model, setModel] = useState('');
  const [models, setModels] = useState<string[]>([]);
  const [showPassword, setShowPassword] = useState(false);
  const [showKey, setShowKey] = useState(false);
  const [busy, setBusy] = useState(false);
  const [tested, setTested] = useState(false);
  const [message, setMessage] = useState('');
  const loginOnly = configured && hasAccount;
  const accountOnly = configured && !hasAccount;
  const loadModels = async () => {
    if (!apiKey.trim()) { setMessage('Enter your Groq API key first.'); return; }
    setBusy(true); setMessage('Loading available Groq models…');
    try {
      const response = await fetch('/api/setup/models', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ apiKey }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Could not load models.');
      setModels(result.models as string[]);
      if (!model && result.models?.length) setModel(result.models[0]);
      setMessage(`Loaded ${result.models.length} models. You can also enter a model ID manually.`);
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Could not load Groq models.'); }
    finally { setBusy(false); }
  };
  const testConnection = async () => {
    if (!apiKey.trim() || !model.trim()) { setMessage('Enter your Groq API key and model first.'); return; }
    setBusy(true); setTested(false); setMessage('Testing your Groq connection…');
    try {
      const response = await fetch('/api/setup/test', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ apiKey, model }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Connection test failed.');
      setTested(true); setMessage('Connection successful. Your key stays on the Monster AI server.');
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Connection test failed.'); }
    finally { setBusy(false); }
  };
  const submit = async (event: React.FormEvent) => {
    event.preventDefault(); setBusy(true); setMessage('');
    try {
      const response = await fetch(loginOnly ? '/api/auth/login' : '/api/setup/save', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(loginOnly || accountOnly ? { username, password } : { username, password, apiKey, model }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Could not continue.');
      onComplete(username);
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Could not continue.'); }
    finally { setBusy(false); }
  };
  const secureField = (label: string, value: string, setValue: (v: string) => void, visible: boolean, toggle: () => void, autoComplete: string) => (
    <label className="setup-label">{label}<span className="setup-input-wrap"><input aria-label={label} type={visible ? 'text' : 'password'} value={value} onChange={(event) => { setValue(event.target.value); setTested(false); }} autoComplete={autoComplete} required />
      <button className="setup-reveal" type="button" aria-label={visible ? `Hide ${label}` : `Show ${label}`} onClick={toggle}>{visible ? <EyeOff size={17} /> : <Eye size={17} />}</button></span></label>
  );
  return <main className="setup-page"><section className="setup-card">
    <div className="setup-brand"><div className="setup-crown">♛</div><div className="setup-wordmark">Monster AI<span>PERSONAL AI WORKSPACE</span></div></div>
    <div className="setup-heading"><span className="setup-overline">{loginOnly ? 'WELCOME BACK' : 'FIRST-TIME SETUP'}</span><h1>{loginOnly ? 'Welcome back.' : accountOnly ? 'One last step.' : 'Make Monster AI yours.'}</h1><p>{loginOnly ? 'Sign in to continue to your workspace.' : accountOnly ? 'Create your Monster AI login to continue.' : 'Set up your account and connect your Groq AI.'}</p></div>
    <form onSubmit={submit} className="setup-form">
      <label className="setup-label">Username<input aria-label="Username" value={username} onChange={(event) => setUsername(event.target.value)} autoComplete="username" required /></label>
      {secureField('Monster AI Password', password, setPassword, showPassword, () => setShowPassword((v) => !v), hasAccount ? 'current-password' : 'new-password')}
      {!loginOnly && !configured && <>
        {secureField('Groq API Key', apiKey, setApiKey, showKey, () => setShowKey((v) => !v), 'off')}
        <label className="setup-label">AI Model<div className="setup-model-row"><input aria-label="AI Model" list="groq-model-options" value={model} onChange={(event) => { setModel(event.target.value); setTested(false); }} placeholder="Enter or choose a Groq model" required /><datalist id="groq-model-options">{models.map((id) => <option key={id} value={id} />)}</datalist><button className="setup-fetch-models" type="button" onClick={() => void loadModels()} disabled={busy || !apiKey.trim()} aria-label="Load Groq models"><ChevronDown size={17} /></button></div><small>Load available models or type any compatible model ID.</small></label>
        <button className={`setup-test ${tested ? 'tested' : ''}`} type="button" onClick={() => void testConnection()} disabled={busy || !apiKey || !model}>{tested ? <Check size={16} /> : <Activity size={16} />}{tested ? 'Connection verified' : 'Test AI Connection'}</button>
      </>}
      {message && <p className={`setup-message ${tested ? 'success' : ''}`} role="status">{message}</p>}
      <button className="setup-submit" type="submit" disabled={busy || (!loginOnly && !accountOnly && !tested)}>{busy ? 'Please wait…' : loginOnly ? 'Login & Continue' : accountOnly ? 'Continue to Monster AI' : 'Save & Continue'}<ArrowRight size={17} /></button>
    </form>
    <div className="setup-foot"><ShieldCheck size={15} /><span>Your API key is stored by the Monster AI server and never saved in this browser.</span></div>
  </section></main>;
}
function App() {
  const [gate, setGate] = useState<'loading' | 'setup' | 'app'>('loading');
  const [setupState, setSetupState] = useState({ configured: false, hasAccount: false });
  const [username, setUsername] = useState('');
  const [tasks, setTasks] = useState(() => read('tasks', seedTasks)),
    [notes, setNotes] = useState(() => read('notes', seedNotes)),
    [entries, setEntries] = useState<Entry[]>(() => read('entries', [])),
    [menu, setMenu] = useState(false),
    [aiHealth, setAiHealth] = useState<AIHealthView>({ provider: 'openai-compatible', configured: false, model: 'openai/gpt-oss-20b', status: 'checking' });
  const navigate = useNavigate();
  useEffect(() => {
    Promise.all([fetch('/api/setup/status').then((r) => r.json()), fetch('/api/auth/status').then((r) => r.json())])
      .then(([setup, auth]) => {
        setSetupState(setup);
        setUsername(auth.username || '');
        setGate(auth.authenticated ? 'app' : 'setup');
      })
      .catch(() => setGate('setup'));
  }, []);
  useEffect(() => {
    fetch('/api/ai/status')
      .then((response) => {
        if (!response.ok) throw new Error('API unavailable');
        return response.json() as Promise<AIHealthView>;
      })
      .then(setAiHealth)
      .catch(() => setAiHealth((health) => ({ ...health, provider: 'unavailable', status: 'offline' })));
  }, []);
  useEffect(() => save('tasks', tasks), [tasks]);
  useEffect(() => save('notes', notes), [notes]);
  useEffect(() => save('entries', entries), [entries]);
  const toggle = (id: string) =>
    setTasks((x) => x.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));
  if (gate === 'loading') return <div className="setup-loading">Monster AI is getting ready…</div>;
  if (gate === 'setup') return <SetupScreen configured={setupState.configured} hasAccount={setupState.hasAccount} onComplete={(name) => { setUsername(name); setGate('app'); }} />;
  return (
    <div className="app">
      <aside className={`sidebar ${menu ? 'show' : ''}`}>
        <div className="brand">
          <div className="brand-mark">
            <Sparkles size={19} />
          </div>
          <div>
            <b>Monster AI</b>
            <small>Your personal assistant</small>
          </div>
          <button className="mobile-close" onClick={() => setMenu(false)}>
            <X />
          </button>
        </div>
        <button className="new-chat" onClick={() => navigate('/chat')}>
          <Plus size={17} /> New conversation <span>⌘ K</span>
        </button>
        <div className="nav-label">WORKSPACE</div>
        <nav>
          {nav.map(([name, to, Icon]) => (
            <NavLink
              key={to}
              to={to}
              onClick={() => setMenu(false)}
              className={({ isActive }) => (isActive ? 'nav-item active' : 'nav-item')}
            >
              <Icon size={18} />
              {name}
              {to === '/tasks' && tasks.filter((t) => !t.done).length > 0 && (
                <em>{tasks.filter((t) => !t.done).length}</em>
              )}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="ai-status">
            <span className={`status-dot ai-${aiHealth.status}`} />
            <div>
              <b>{aiHealth.status === 'checking' ? 'Checking AI…' : aiHealth.provider === 'ollama' ? aiHealth.status === 'online' ? 'Local AI online' : aiHealth.status === 'model_missing' ? 'Local model missing' : 'Local AI offline' : aiHealth.provider === 'unavailable' ? 'Monster AI server offline' : aiHealth.configured ? 'Online AI ready' : 'Online AI needs setup'}</b>
              <small>{aiHealth.model} · local tools available</small>
            </div>
            <ChevronDown size={15} />
          </div>
          <div className="profile">
            <div className="avatar">Y</div>
            <div>
              <b>{username || 'Your workspace'}</b>
              <small>Personal plan</small>
            </div>
            <span className="more">···</span>
          </div>
        </div>
      </aside>
      <main className="main">
        <header className="topbar">
          <button className="menu-button" onClick={() => setMenu(!menu)}>
            <Menu />
          </button>
          <div className="crumb">
            Workspace <span>/</span>{' '}
            <b>{nav.find((x) => x[1] === location.pathname)?.[0] || 'Overview'}</b>
          </div>
          <div className="top-actions">
            <button className="search-btn" onClick={() => navigate('/chat')}>
              <Search size={16} /> <span>Search anything</span>
              <kbd>⌘ K</kbd>
            </button>
            <button className="icon-button" aria-label="Help">
              <CircleHelp size={18} />
            </button>
            <div className="avatar small-avatar">Y</div>
          </div>
        </header>
        <div className="content">
          <Routes>
            <Route
              path="/"
              element={
                <Dashboard tasks={tasks} toggle={toggle} navigate={navigate} entries={entries} />
              }
            />
            <Route
              path="/tasks"
              element={<Tasks tasks={tasks} setTasks={setTasks} toggle={toggle} />}
            />
            <Route path="/notes" element={<Notes notes={notes} setNotes={setNotes} />} />
            <Route path="/budget" element={<Budget entries={entries} setEntries={setEntries} />} />
            <Route path="/study" element={<Study />} />
            <Route path="/timetable" element={<Timetable />} />
            <Route path="/chat" element={<Chat health={aiHealth} />} />
            <Route path="/settings" element={<SettingsPage />} />
          </Routes>
        </div>
      </main>
    </div>
  );
}
function Dashboard({
  tasks,
  toggle,
  navigate,
  entries,
}: {
  tasks: Task[];
  toggle: (id: string) => void;
  navigate: (to: string) => void;
  entries: Entry[];
}) {
  const done = tasks.filter((t) => t.done).length;
  const balance = entries.reduce((s, e) => s + (e.kind === 'income' ? e.amount : -e.amount), 0);
  return (
    <>
      <div className="welcome">
        <div>
          <div className="eyebrow">
            <span className="sun">✦</span>{' '}
            {new Intl.DateTimeFormat('en-US', { weekday: 'long', month: 'long', day: 'numeric' })
              .format(new Date())
              .toUpperCase()}
          </div>
          <h1>A little progress goes a long way.</h1>
          <p>Good evening. What would you like to focus on today?</p>
        </div>
        <div className="welcome-art">
          <div className="art-orbit orbit-one" />
          <div className="art-orbit orbit-two" />
          <Sparkles size={34} />
        </div>
      </div>
      <div className="quick-grid">
        <button className="quick-card lavender" onClick={() => navigate('/chat')}>
          <span className="quick-icon">
            <MessageSquare />
          </span>
          <span>
            <b>Ask Monster AI</b>
            <small>Get help with anything</small>
          </span>
          <ArrowRight />
        </button>
        <button className="quick-card mint" onClick={() => navigate('/study')}>
          <span className="quick-icon">
            <Timer />
          </span>
          <span>
            <b>Start a focus session</b>
            <small>Make time for deep work</small>
          </span>
          <ArrowRight />
        </button>
        <button className="quick-card peach" onClick={() => navigate('/tasks')}>
          <span className="quick-icon">
            <ListTodo />
          </span>
          <span>
            <b>Plan your day</b>
            <small>Keep your priorities clear</small>
          </span>
          <ArrowRight />
        </button>
      </div>
      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-head">
            Tasks completed{' '}
            <span className="stat-icon blue">
              <Check />
            </span>
          </div>
          <div className="stat-value">
            {done}
            <small> / {tasks.length}</small>
          </div>
          <div className="stat-foot">
            <div className="progress">
              <span style={{ width: `${tasks.length ? (done / tasks.length) * 100 : 0}%` }} />
            </div>
            <span>{tasks.length ? Math.round((done / tasks.length) * 100) : 0}%</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-head">
            Focus this week{' '}
            <span className="stat-icon green">
              <Clock3 />
            </span>
          </div>
          <div className="stat-value">
            0<small>h</small> 00<small>m</small>
          </div>
          <div className="stat-foot muted">
            <Activity size={14} /> Start a session to track focus
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-head">
            Budget balance{' '}
            <span className="stat-icon purple">
              <Wallet />
            </span>
          </div>
          <div className="stat-value">
            ${balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="stat-foot muted">From your recorded transactions</div>
        </div>
      </div>
      <div className="section-row">
        <div>
          <h2>Your day</h2>
          <p>A clear plan makes all the difference.</p>
        </div>
        <button className="text-link" onClick={() => navigate('/tasks')}>
          View all tasks <ArrowRight size={15} />
        </button>
      </div>
      <div className="tasks-panel">
        {tasks.slice(0, 4).map((t) => (
          <div className="task-row" key={t.id}>
            <button
              className={`check-circle ${t.done ? 'checked' : ''}`}
              onClick={() => toggle(t.id)}
            >
              {t.done && <Check size={13} />}
            </button>
            <span className={t.done ? 'task-done' : ''}>{t.title}</span>
            <span className={`priority ${t.priority.toLowerCase()}`}>{t.priority}</span>
          </div>
        ))}
        <button className="add-inline" onClick={() => navigate('/tasks')}>
          <Plus size={15} /> Add a task
        </button>
      </div>
      <div className="bottom-grid">
        <div className="panel">
          <div className="panel-heading">
            <div>
              <h3>Study streak</h3>
              <p>Small steps, every day.</p>
            </div>
            <Flame className="flame" />
          </div>
          <div className="streak-empty">
            <span>✦</span>
            <b>Your next session starts a streak.</b>
            <small>Focus time is tracked when you use the study timer.</small>
            <button className="button-soft" onClick={() => navigate('/study')}>
              Start studying <ArrowRight size={14} />
            </button>
          </div>
        </div>
        <div className="panel">
          <div className="panel-heading">
            <div>
              <h3>Quick access</h3>
              <p>Pick up where you left off.</p>
            </div>
          </div>
          <button className="recent-item" onClick={() => navigate('/notes')}>
            <div className="recent-icon">
              <FileText size={17} />
            </div>
            <div>
              <b>My notes</b>
              <small>{notesCount()} saved notes</small>
            </div>
            <ArrowRight size={16} />
          </button>
          <button className="recent-item" onClick={() => navigate('/budget')}>
            <div className="recent-icon green">
              <Wallet size={17} />
            </div>
            <div>
              <b>My budget</b>
              <small>Track income and spending</small>
            </div>
            <ArrowRight size={16} />
          </button>
        </div>
      </div>
    </>
  );
}
function notesCount() {
  return read<Note[]>('notes', seedNotes).length;
}
function PageTitle({
  eyebrow,
  title,
  desc,
  action,
}: {
  eyebrow: string;
  title: string;
  desc: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="page-title">
      <div className="eyebrow">{eyebrow}</div>
      <div className="title-line">
        <div>
          <h1>{title}</h1>
          <p>{desc}</p>
        </div>
        {action}
      </div>
    </div>
  );
}
function Tasks({
  tasks,
  setTasks,
  toggle,
}: {
  tasks: Task[];
  setTasks: (v: Task[] | ((x: Task[]) => Task[])) => void;
  toggle: (id: string) => void;
}) {
  const [text, setText] = useState('');
  const [filter, setFilter] = useState('All tasks');
  const filtered = tasks.filter((t) =>
    filter === 'Completed' ? t.done : filter === 'To do' ? !t.done : true,
  );
  return (
    <>
      <PageTitle
        eyebrow="YOUR WORKSPACE"
        title="My tasks"
        desc="Keep the important things moving."
        action={<span className="count-pill">{tasks.filter((t) => !t.done).length} remaining</span>}
      />
      <div className="panel page-panel">
        <div className="add-task">
          <Plus size={18} />
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Add a task and press Enter…"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && text.trim()) {
                setTasks((x) => [
                  {
                    id: crypto.randomUUID(),
                    title: text.trim(),
                    done: false,
                    priority: 'Medium',
                    due: today,
                  },
                  ...x,
                ]);
                setText('');
              }
            }}
          />
          <button
            onClick={() => {
              if (text.trim()) {
                setTasks((x) => [
                  {
                    id: crypto.randomUUID(),
                    title: text.trim(),
                    done: false,
                    priority: 'Medium',
                    due: today,
                  },
                  ...x,
                ]);
                setText('');
              }
            }}
          >
            Add task
          </button>
        </div>
        <div className="filter-row">
          {['All tasks', 'To do', 'Completed'].map((f) => (
            <button
              key={f}
              className={filter === f ? 'filter-active' : ''}
              onClick={() => setFilter(f)}
            >
              {f}
            </button>
          ))}
        </div>
        {filtered.length ? (
          filtered.map((t) => (
            <div className="task-row full-task" key={t.id}>
              <button
                className={`check-circle ${t.done ? 'checked' : ''}`}
                onClick={() => toggle(t.id)}
              >
                {t.done && <Check size={13} />}
              </button>
              <span className={t.done ? 'task-done' : ''}>{t.title}</span>
              <span className={`priority ${t.priority.toLowerCase()}`}>{t.priority}</span>
              <button
                className="delete-btn"
                onClick={() => setTasks((x) => x.filter((y) => y.id !== t.id))}
              >
                <X size={15} />
              </button>
            </div>
          ))
        ) : (
          <div className="empty-state">Nothing here yet. Add a task to get started.</div>
        )}
      </div>
    </>
  );
}
function Notes({
  notes,
  setNotes,
}: {
  notes: Note[];
  setNotes: (v: Note[] | ((x: Note[]) => Note[])) => void;
}) {
  const [editing, setEditing] = useState<Note | null>(null);
  return (
    <>
      <PageTitle
        eyebrow="YOUR WORKSPACE"
        title="Notes"
        desc="A home for the things you want to remember."
        action={
          <button
            className="primary-btn"
            onClick={() =>
              setEditing({ id: crypto.randomUUID(), title: '', body: '', updated: 'Just now' })
            }
          >
            <Plus size={16} /> New note
          </button>
        }
      />
      {editing && (
        <div className="modal-backdrop">
          <div className="modal">
            <button className="modal-close" onClick={() => setEditing(null)}>
              <X />
            </button>
            <h2>{editing.title ? 'Edit note' : 'New note'}</h2>
            <input
              className="field"
              placeholder="Note title"
              value={editing.title}
              onChange={(e) => setEditing({ ...editing, title: e.target.value })}
            />
            <textarea
              className="field note-body"
              placeholder="Write something worth remembering…"
              value={editing.body}
              onChange={(e) => setEditing({ ...editing, body: e.target.value })}
            />
            <button
              className="primary-btn"
              onClick={() => {
                if (editing.title.trim()) {
                  setNotes((x) => [editing, ...x.filter((n) => n.id !== editing.id)]);
                  setEditing(null);
                }
              }}
            >
              <Check size={16} /> Save note
            </button>
          </div>
        </div>
      )}
      <div className="notes-grid">
        {notes.map((n) => (
          <article className="note-card" key={n.id} onClick={() => setEditing(n)}>
            <div className="note-card-top">
              <span className="recent-icon">
                <FileText size={17} />
              </span>
              <button
                className="delete-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  setNotes((x) => x.filter((v) => v.id !== n.id));
                }}
              >
                <X size={15} />
              </button>
            </div>
            <h3>{n.title}</h3>
            <p>{n.body || 'No content yet.'}</p>
            <small>{n.updated}</small>
          </article>
        ))}
      </div>
    </>
  );
}
function Budget({
  entries,
  setEntries,
}: {
  entries: Entry[];
  setEntries: (v: Entry[] | ((x: Entry[]) => Entry[])) => void;
}) {
  const [title, setTitle] = useState(''),
    [amount, setAmount] = useState(''),
    [kind, setKind] = useState<'income' | 'expense'>('expense'),
    [category, setCategory] = useState('General');
  const income = entries.filter((e) => e.kind === 'income').reduce((s, e) => s + e.amount, 0),
    expense = entries.filter((e) => e.kind === 'expense').reduce((s, e) => s + e.amount, 0);
  return (
    <>
      <PageTitle
        eyebrow="YOUR FINANCES"
        title="Budget"
        desc="A simple, private view of money in and out."
      />
      <div className="budget-stats">
        <div className="stat-card">
          <div className="stat-head">Balance</div>
          <div className="stat-value">${(income - expense).toFixed(2)}</div>
          <div className="stat-foot muted">Based on recorded entries</div>
        </div>
        <div className="stat-card">
          <div className="stat-head">
            Income <ArrowUpRight size={16} />
          </div>
          <div className="stat-value green-text">${income.toFixed(2)}</div>
        </div>
        <div className="stat-card">
          <div className="stat-head">
            Expenses <ArrowDownRight size={16} />
          </div>
          <div className="stat-value coral-text">${expense.toFixed(2)}</div>
        </div>
      </div>
      <div className="budget-layout">
        <div className="panel page-panel">
          <h3>Record a transaction</h3>
          <p className="panel-sub">Your entries stay in this browser.</p>
          <div className="segmented">
            <button
              className={kind === 'expense' ? 'selected' : ''}
              onClick={() => setKind('expense')}
            >
              Expense
            </button>
            <button
              className={kind === 'income' ? 'selected' : ''}
              onClick={() => setKind('income')}
            >
              Income
            </button>
          </div>
          <input
            className="field"
            placeholder="Description"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <div className="form-row">
            <input
              className="field"
              type="number"
              min="0"
              step="0.01"
              placeholder="Amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
            <select
              className="field"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              {['General', 'Food', 'Transport', 'Study', 'Bills', 'Shopping', 'Other'].map((x) => (
                <option key={x}>{x}</option>
              ))}
            </select>
          </div>
          <button
            className="primary-btn full-width"
            onClick={() => {
              const v = Number(amount);
              if (title.trim() && v > 0) {
                setEntries((x) => [
                  {
                    id: crypto.randomUUID(),
                    title: title.trim(),
                    amount: v,
                    kind,
                    category,
                    date: today,
                  },
                  ...x,
                ]);
                setTitle('');
                setAmount('');
              }
            }}
          >
            Save transaction
          </button>
        </div>
        <div className="panel page-panel">
          <h3>Recent transactions</h3>
          {entries.length ? (
            entries.map((e) => (
              <div className="transaction" key={e.id}>
                <div className="recent-icon">
                  {e.kind === 'income' ? <ArrowDownRight /> : <ArrowUpRight />}
                </div>
                <div className="transaction-name">
                  <b>{e.title}</b>
                  <small>
                    {e.category} · {e.date}
                  </small>
                </div>
                <b className={e.kind === 'income' ? 'green-text' : 'coral-text'}>
                  {e.kind === 'income' ? '+' : '−'}${e.amount.toFixed(2)}
                </b>
                <button
                  className="delete-btn"
                  onClick={() => setEntries((x) => x.filter((y) => y.id !== e.id))}
                >
                  <X size={14} />
                </button>
              </div>
            ))
          ) : (
            <div className="empty-state">No transactions yet. Add one to see your budget.</div>
          )}
        </div>
      </div>
    </>
  );
}
function Study() {
  const [seconds, setSeconds] = useState(25 * 60),
    [running, setRunning] = useState(false),
    [minutes, setMinutes] = useState('25'),
    [sessions, setSessions] = useState(() => read<number>('sessions', 0));
  useEffect(() => {
    if (!running) return;
    const id = setInterval(
      () =>
        setSeconds((s) => {
          if (s <= 1) {
            setRunning(false);
            const c = read<number>('sessions', 0) + 1;
            save('sessions', c);
            setSessions(c);
            return Number(minutes) * 60;
          }
          return s - 1;
        }),
      1000,
    );
    return () => clearInterval(id);
  }, [running, minutes]);
  const reset = () => {
    setRunning(false);
    setSeconds(Number(minutes) * 60);
  };
  return (
    <>
      <PageTitle
        eyebrow="STUDY SPACE"
        title="Focus timer"
        desc="Give one thing your full attention."
      />
      <div className="focus-layout">
        <div className="panel focus-panel">
          <div className="timer-label">
            <span className="status-dot" /> FOCUS SESSION
          </div>
          <div className="timer-display">
            {String(Math.floor(seconds / 60)).padStart(2, '0')}
            <span>:</span>
            {String(seconds % 60).padStart(2, '0')}
          </div>
          <div className="timer-controls">
            <button className="primary-btn" onClick={() => setRunning(!running)}>
              {running ? 'Pause' : 'Start focus'}
            </button>
            <button className="button-soft" onClick={reset}>
              Reset
            </button>
          </div>
          <div className="timer-custom">
            <span>Session length</span>
            <input
              type="number"
              min="1"
              max="180"
              value={minutes}
              onChange={(e) => {
                setMinutes(e.target.value);
                if (!running) setSeconds(Number(e.target.value) * 60);
              }}
            />
            <span>minutes</span>
            <button onClick={reset}>Apply</button>
          </div>
        </div>
        <div className="panel focus-aside">
          <span className="stat-icon green">
            <Flame />
          </span>
          <h3>Keep showing up.</h3>
          <p>Each focused session is a small investment in your future self.</p>
          <div className="session-number">
            {sessions}
            <small> completed sessions on this device</small>
          </div>
          <div className="panel-sub">Your timer works offline. Sessions are stored locally.</div>
        </div>
      </div>
    </>
  );
}
function Timetable() {
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const [events, setEvents] = useState(() =>
      read<{ id: string; day: string; time: string; title: string }[]>('events', []),
    ),
    [title, setTitle] = useState(''),
    [day, setDay] = useState('Monday'),
    [time, setTime] = useState('09:00');
  useEffect(() => save('events', events), [events]);
  return (
    <>
      <PageTitle
        eyebrow="YOUR WORKSPACE"
        title="Timetable"
        desc="Build a weekly rhythm that works for you."
      />
      <div className="panel page-panel">
        <div className="add-task timetable-add">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Class or activity"
          />
          <select value={day} onChange={(e) => setDay(e.target.value)}>
            {days.map((d) => (
              <option key={d}>{d}</option>
            ))}
          </select>
          <input type="time" value={time} onChange={(e) => setTime(e.target.value)} />
          <button
            onClick={() => {
              if (title.trim()) {
                setEvents((x) => [
                  ...x,
                  { id: crypto.randomUUID(), day, time, title: title.trim() },
                ]);
                setTitle('');
              }
            }}
          >
            <Plus size={15} /> Add
          </button>
        </div>
        <div className="week-grid">
          {days.map((d) => (
            <div className="day-column" key={d}>
              <b>{d.slice(0, 3)}</b>
              {events
                .filter((e) => e.day === d)
                .sort((a, b) => a.time.localeCompare(b.time))
                .map((e) => (
                  <div className="event-chip" key={e.id}>
                    <small>{e.time}</small>
                    <span>{e.title}</span>
                    <button onClick={() => setEvents((x) => x.filter((y) => y.id !== e.id))}>
                      <X size={12} />
                    </button>
                  </div>
                ))}
            </div>
          ))}
        </div>
        {events.length === 0 && (
          <div className="empty-state">Your week is open. Add a class or activity above.</div>
        )}
      </div>
    </>
  );
}
function Chat({ health }: { health: AIHealthView }) {
  const [messages, setMessages] = useState<{ role: string; content: string }[]>(() =>
      read('messages', []),
    ),
    [input, setInput] = useState(''),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  useEffect(() => save('messages', messages), [messages]);
  const send = async () => {
    if (!input.trim() || busy) return;
    const user = { role: 'user', content: input.trim() };
    const next = [...messages, user];
    setMessages(next);
    setInput('');
    setBusy(true);
    setError('');
    try {
      const r = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ messages: next }),
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || 'Assistant is unavailable.');
      setMessages([...next, { role: 'assistant', content: data.message }]);
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : 'Could not connect to the assistant. Check the Monster AI server and configured AI provider.',
      );
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <PageTitle
        eyebrow="YOUR AI ASSISTANT"
        title="Ask Monster AI"
        desc="A thoughtful assistant for study, work, and everyday questions."
      />
      <div className="chat-panel panel">
        <div className={`local-ai-banner ${health.configured ? 'available' : ''}`}>
          <span className={`status-dot ai-${health.status}`} />
          <span>{health.provider === 'ollama' ? `Local AI ${health.status === 'online' ? 'ready' : health.status === 'model_missing' ? 'needs model' : 'offline'}` : health.provider === 'unavailable' ? 'Monster AI server offline' : `Online AI ${health.configured ? 'ready' : 'needs server setup'}`}</span>
          <small>{health.model}</small>
        </div>
        <div className="chat-messages">
          {messages.length === 0 && (
            <div className="chat-welcome">
              <div className="brand-mark">
                <Sparkles />
              </div>
              <h2>What’s on your mind?</h2>
              <p>Ask a question, work through a problem, or plan your next step.</p>
              <div className="prompt-chips">
                {[
                  'Explain a tricky concept',
                  'Help me plan my study week',
                  'Review a piece of code',
                ].map((t) => (
                  <button key={t} onClick={() => setInput(t)}>
                    {t}
                    <ArrowRight size={14} />
                  </button>
                ))}
              </div>
            </div>
          )}
          {messages.map((m, i) => (
            <div className={`message ${m.role}`} key={i}>
              <div className="message-avatar">
                {m.role === 'user' ? 'Y' : <Sparkles size={15} />}
              </div>
              <div>
                <small>{m.role === 'user' ? 'You' : 'Monster AI'}</small>
                <p>{m.content}</p>
              </div>
            </div>
          ))}
          {busy && (
            <div className="message">
              <div className="message-avatar">
                <Sparkles size={15} />
              </div>
              <p className="typing">Thinking…</p>
            </div>
          )}
          {error && (
            <div className="chat-error">
              <ShieldCheck size={16} />
              {error}
            </div>
          )}
        </div>
        <div className="chat-composer">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                void send();
              }
            }}
            placeholder="Message Monster AI…"
          />
          <div className="composer-foot">
            <span>Enter to send · Shift+Enter for a new line</span>
            <button disabled={busy || !input.trim()} onClick={() => void send()}>
              <Send size={16} />
            </button>
          </div>
        </div>
      </div>
      <p className="privacy-note">
        <ShieldCheck size={14} /> Chat requests go through the Monster AI server. Provider credentials stay on the server.
      </p>
    </>
  );
}
function SettingsPage() {
  const [name, setName] = useState(() => read('name', ''));
  return (
    <>
      <PageTitle
        eyebrow="PREFERENCES"
        title="Settings"
        desc="Make your workspace feel like yours."
      />
      <div className="panel page-panel settings-panel">
        <h3>Profile</h3>
        <p className="panel-sub">Used to personalize your workspace on this device.</p>
        <label className="field-label">
          Your name
          <input
            className="field"
            value={name}
            placeholder="What should Monster AI call you?"
            onChange={(e) => {
              setName(e.target.value);
              save('name', e.target.value);
            }}
          />
        </label>
        <hr />
        <AIConfiguration />
        <hr />
        <h3>Data and privacy</h3>
        <p className="panel-sub">
          Your tasks, notes, and budget entries are stored in this browser.
        </p>
        <button
          className="button-soft"
          onClick={() => {
            const blob = new Blob(
              [
                JSON.stringify(
                  {
                    tasks: read('tasks', seedTasks),
                    notes: read('notes', seedNotes),
                    entries: read('entries', []),
                    events: read('events', []),
                    sessions: read('sessions', 0),
                  },
                  null,
                  2,
                ),
              ],
              { type: 'application/json' },
            );
            const a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = 'daddy-personal-data.json';
            a.click();
            URL.revokeObjectURL(a.href);
          }}
        >
          Export my data <ArrowRight size={14} />
        </button>
        <hr />
        <button
          className="danger-btn"
          onClick={() => {
            if (confirm('Delete all Monster AI data stored in this browser?')) {
              Object.keys(localStorage)
                .filter((k) => k.startsWith('daddy:'))
                .forEach((k) => localStorage.removeItem(k));
              location.reload();
            }
          }}
        >
          Delete local data
        </button>
        <hr />
        <button className="button-soft" onClick={async () => { await fetch('/api/auth/logout', { method: 'POST' }); location.reload(); }}>Sign out <ArrowRight size={14} /></button>
      </div>
    </>
  );
}
function AIConfiguration() {
  const [apiKey, setApiKey] = useState('');
  const [model, setModel] = useState('');
  const [models, setModels] = useState<string[]>([]);
  const [visible, setVisible] = useState(false);
  const [busy, setBusy] = useState(false);
  const [tested, setTested] = useState(false);
  const [message, setMessage] = useState('');
  useEffect(() => { fetch('/api/ai/status').then((response) => response.json()).then((result) => setModel(result.model || '')).catch(() => undefined); }, []);
  const getModels = async () => {
    setBusy(true);
    try { const response = await fetch('/api/setup/models', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ apiKey }) }); const result = await response.json(); if (!response.ok) throw new Error(result.error); setModels(result.models); if (!model && result.models[0]) setModel(result.models[0]); setMessage(`Loaded ${result.models.length} models.`); }
    catch (error) { setMessage(error instanceof Error ? error.message : 'Could not load models.'); } finally { setBusy(false); }
  };
  const test = async () => {
    setBusy(true); setTested(false);
    try { const response = await fetch('/api/setup/test', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ ...(apiKey ? { apiKey } : {}), model }) }); const result = await response.json(); if (!response.ok) throw new Error(result.error); setTested(true); setMessage('Groq connection successful.'); }
    catch (error) { setMessage(error instanceof Error ? error.message : 'Connection test failed.'); } finally { setBusy(false); }
  };
  const saveConfig = async () => {
    setBusy(true);
    try { const response = await fetch('/api/ai/config', { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ ...(apiKey ? { apiKey } : {}), model }) }); const result = await response.json(); if (!response.ok) throw new Error(result.error); setApiKey(''); setMessage('AI configuration saved on the backend.'); }
    catch (error) { setMessage(error instanceof Error ? error.message : 'Could not save AI configuration.'); } finally { setBusy(false); }
  };
  return <section><h3>AI Configuration</h3><p className="panel-sub">Groq credentials stay on the Monster AI server. A blank key field keeps your current key.</p>
    <label className="field-label">Groq API Key<span className="setup-input-wrap settings-secret"><input className="field" aria-label="Groq API Key" type={visible ? 'text' : 'password'} autoComplete="new-password" placeholder="Enter a new key to replace the saved key" value={apiKey} onChange={(event) => { setApiKey(event.target.value); setTested(false); }} /><button className="setup-reveal" type="button" aria-label={visible ? 'Hide Groq API Key' : 'Show Groq API Key'} onClick={() => setVisible((v) => !v)}>{visible ? <EyeOff size={16} /> : <Eye size={16} />}</button></span></label>
    <label className="field-label">AI Model<div className="setup-model-row settings-model"><input className="field" aria-label="Settings AI Model" list="settings-groq-models" value={model} onChange={(event) => { setModel(event.target.value); setTested(false); }} placeholder="Enter a Groq model ID" /><datalist id="settings-groq-models">{models.map((id) => <option key={id} value={id} />)}</datalist><button className="setup-fetch-models" type="button" onClick={() => void getModels()} disabled={busy || !apiKey} aria-label="Load Groq models"><ChevronDown size={17} /></button></div></label>
    <div className="ai-config-actions"><button className="button-soft" type="button" onClick={() => void test()} disabled={busy || !model}>Test AI Connection</button><button className="primary-btn" type="button" onClick={() => void saveConfig()} disabled={busy || !tested}>Save AI settings</button></div>{message && <p className={`setup-message ${tested ? 'success' : ''}`} role="status">{message}</p>}
  </section>;
}
export default App;
