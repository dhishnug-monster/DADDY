// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import App from './App';

describe('Monster AI workspace', () => {
  beforeEach(() => vi.stubGlobal('fetch', vi.fn((input: RequestInfo | URL) => {
    const url = String(input);
    if (url.includes('/api/setup/status')) return Promise.resolve(Response.json({ configured: true, hasAccount: true }));
    if (url.includes('/api/auth/status')) return Promise.resolve(Response.json({ authenticated: true, username: 'tester' }));
    if (url.includes('/api/ai/status')) return Promise.resolve(Response.json({ provider: 'openai-compatible', configured: true, model: 'test-model', status: 'configured' }));
    return Promise.resolve(Response.json({}));
  })));
  afterEach(() => { cleanup(); vi.unstubAllGlobals(); });
  it('renders the dashboard and working navigation', async () => {
    render(
      <BrowserRouter>
        <App />
      </BrowserRouter>,
    );
    expect(await screen.findByText('A little progress goes a long way.')).toBeTruthy();
    expect(screen.getByRole('link', { name: /My tasks/i })).toBeTruthy();
  });
  it('opens AI setup when this server has no account or AI configuration', async () => {
    vi.stubGlobal('fetch', vi.fn((input: RequestInfo | URL) => String(input).includes('/api/setup/status')
      ? Promise.resolve(Response.json({ configured: false, hasAccount: false }))
      : Promise.resolve(Response.json({ authenticated: false }))));
    render(<BrowserRouter><App /></BrowserRouter>);
    expect(await screen.findByRole('heading', { name: 'Make Monster AI yours.' })).toBeTruthy();
    expect(screen.getByLabelText('Groq API Key').getAttribute('type')).toBe('password');
    expect(screen.getByLabelText('AI Model')).toBeTruthy();
    expect(screen.getByRole('button', { name: 'Test AI Connection' })).toBeTruthy();
  });
  it('tests Groq, saves setup without browser storage, and continues to the dashboard', async () => {
    const fetchMock = vi.fn((input: RequestInfo | URL, init?: RequestInit) => {
      void init;
      const url = String(input);
      if (url.includes('/api/setup/status')) return Promise.resolve(Response.json({ configured: false, hasAccount: false }));
      if (url.includes('/api/auth/status')) return Promise.resolve(Response.json({ authenticated: false }));
      if (url.includes('/api/setup/test')) return Promise.resolve(Response.json({ ok: true }));
      if (url.includes('/api/setup/save')) return Promise.resolve(Response.json({ ok: true }));
      return Promise.resolve(Response.json({ provider: 'openai-compatible', configured: true, model: 'model-test', status: 'configured' }));
    });
    vi.stubGlobal('fetch', fetchMock);
    render(<BrowserRouter><App /></BrowserRouter>);
    fireEvent.change(await screen.findByLabelText('Username'), { target: { value: 'student' } });
    fireEvent.change(screen.getByLabelText('Monster AI Password'), { target: { value: 'a-safe-test-password' } });
    fireEvent.change(screen.getByLabelText('Groq API Key'), { target: { value: 'fake-test-key' } });
    fireEvent.change(screen.getByLabelText('AI Model'), { target: { value: 'compatible-model-id' } });
    fireEvent.click(screen.getByRole('button', { name: 'Test AI Connection' }));
    expect(await screen.findByText(/Connection successful/)).toBeTruthy();
    fireEvent.click(screen.getByRole('button', { name: 'Save & Continue' }));
    expect(await screen.findByText('A little progress goes a long way.')).toBeTruthy();
    const saveCall = fetchMock.mock.calls.find(([url]) => String(url).includes('/api/setup/save'));
    expect(saveCall).toBeTruthy();
    expect(String(saveCall?.[1]?.body)).toContain('fake-test-key');
    expect(localStorage.getItem('daddy:apiKey')).toBeNull();
  });
});
