import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
const apiTarget = process.env.DADDY_API_URL ?? 'http://localhost:3001';
export default defineConfig({
  plugins: [react()],
  server: { port: 5173, proxy: { '/api': apiTarget } },
  preview: { port: 5173, strictPort: true, proxy: { '/api': apiTarget } },
});
