@echo off
setlocal
set "DADDY_ROOT=%~dp0"
cd /d "%DADDY_ROOT%"

rem Require Node.js; npm/Corepack come with most current Node.js installations.
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 20 or later is required. Install Node.js, then retry.
  pause
  exit /b 1
)

rem Prefer an existing pnpm installation.
set "PNPM_CMD="
where pnpm >nul 2>nul
if not errorlevel 1 set "PNPM_CMD=pnpm"

rem Use Corepack if pnpm is not on PATH, enabling and activating it when needed.
if not defined PNPM_CMD (
  where corepack >nul 2>nul
  if not errorlevel 1 (
    call corepack pnpm --version >nul 2>nul
    if errorlevel 1 (
      echo Enabling pnpm through Corepack...
      call corepack enable pnpm >nul 2>nul
      call corepack prepare pnpm@9.15.9 --activate >nul 2>nul
      call corepack pnpm --version >nul 2>nul
    )
    if not errorlevel 1 set "PNPM_CMD=corepack pnpm"
  )
)

rem If Corepack is unavailable, use npm's one-shot package runner.
if not defined PNPM_CMD (
  where npm >nul 2>nul
  if not errorlevel 1 (
    echo Bootstrapping pnpm through npm. Internet may be required the first time.
    call npm exec --yes --package=pnpm@9.15.9 -- pnpm --version >nul 2>nul
    if not errorlevel 1 set "PNPM_CMD=npm exec --yes --package=pnpm@9.15.9 -- pnpm"
  )
)

if not defined PNPM_CMD (
  echo Could not set up pnpm automatically. Check that Node.js includes Corepack or npm and that internet access is available.
  pause
  exit /b 1
)

if not exist "backend\.env" (
  copy "backend\.env.example" "backend\.env" >nul
  if errorlevel 1 (
    echo Could not create backend\.env from its example file.
    pause
    exit /b 1
  )
  echo Created backend\.env. Add your Groq key there to enable AI chat.
)

if not exist "node_modules" (
  echo Installing DADDY dependencies...
  call %PNPM_CMD% install
  if errorlevel 1 (
    echo Dependency installation failed.
    pause
    exit /b 1
  )
)

start "DADDY Backend" cmd /k "cd /d ""%DADDY_ROOT%backend"" ^&^& %PNPM_CMD% dev"
start "DADDY Frontend" cmd /k "cd /d ""%DADDY_ROOT%frontend"" ^&^& %PNPM_CMD% dev"
timeout /t 3 /nobreak >nul
start "" http://localhost:5173
echo DADDY is starting. Frontend: http://localhost:5173  Backend: http://localhost:3001
